package com.example.resthateoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestHateoasApplicationTests {

	@Test
	void contextLoads() {
	}

}
